package ar.edu.unlam.pb2;

import java.util.List;

public class Evento {
	
	private String nombreDelEvento;
	private List<Invitado> invitados;
	private Organizador organizador;
	
	public Evento(String nombreDelEvento, List<Invitado> invitados, Organizador organizador) {
		super();
		this.nombreDelEvento = nombreDelEvento;
		this.invitados = invitados;
		this.organizador = organizador;
	}

	public String getNombreDelEvento() {
		return nombreDelEvento;
	}

	public void setNombreDelEvento(String nombreDelEvento) {
		this.nombreDelEvento = nombreDelEvento;
	}

	public List<Invitado> getInvitados() {
		return invitados;
	}

	public void setInvitados(List<Invitado> invitados) {
		this.invitados = invitados;
	}

	public Organizador getOrganizador() {
		return organizador;
	}

	public void setOrganizador(Organizador organizador) {
		this.organizador = organizador;
	}
	
	
	
	

}
