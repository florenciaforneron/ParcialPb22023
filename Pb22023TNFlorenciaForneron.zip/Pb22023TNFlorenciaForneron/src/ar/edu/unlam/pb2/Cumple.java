package ar.edu.unlam.pb2;

import java.util.List;

public class Cumple extends Evento{

	public Cumple(String nombreDelEvento, List<Invitado> invitados, Organizador organizador) {
		super(nombreDelEvento, invitados, organizador);
		// TODO Auto-generated constructor stub
	}

}
