package ar.edu.unlam.pb2;

public class Invitado extends Usuario{

	public Invitado(String mail, String nombre, Integer edad) {
		super(mail, nombre, edad);
		// TODO Auto-generated constructor stub
	}


}
