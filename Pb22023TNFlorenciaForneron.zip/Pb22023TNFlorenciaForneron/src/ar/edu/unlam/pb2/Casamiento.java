package ar.edu.unlam.pb2;

import java.util.List;

public class Casamiento extends Evento{

	public Casamiento(String nombreDelEvento, List<Invitado> invitados, Organizador organizador) {
		super(nombreDelEvento, invitados, organizador);
		// TODO Auto-generated constructor stub
	}

}
