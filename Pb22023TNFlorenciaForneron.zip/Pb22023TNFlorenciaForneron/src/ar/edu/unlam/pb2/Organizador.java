package ar.edu.unlam.pb2;

public class Organizador extends Usuario{

	public Organizador(String mail, String nombre, Integer edad) {
		super(mail, nombre, edad);
		
	}
	
	
	
	
	
	

}
