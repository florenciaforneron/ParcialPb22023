package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class PlanificadorDeEventos {
	
	private Usuario usuario;
	private Evento evento;
	//private List<Usuario> usuarios;
	//private List<Evento> eventos;
		
	public void add(Usuario usuario) {
		// TODO Auto-generated method stub
		
	}
	
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Evento getEvento() {
		return evento;
	}

	public void setEvento(Evento evento) {
		this.evento = evento;
	}

	public void crear(String mail, Evento evento) {
		 List<Usuario> usuarios = new ArrayList<Usuario>();
		 List<Evento> eventos = new ArrayList<Evento>();
		 
		 usuarios.add(usuario);
		
		
	}
	
	public Object getCantidadDeUsuarios() {
		// TODO Auto-generated method stub
		return null;
	}



	

	

	

}
