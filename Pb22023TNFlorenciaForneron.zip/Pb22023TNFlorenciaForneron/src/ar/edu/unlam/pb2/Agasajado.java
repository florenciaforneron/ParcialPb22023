package ar.edu.unlam.pb2;

public class Agasajado extends Usuario{

	public Agasajado(String mail, String nombre, Integer edad) {
		super(mail, nombre, edad);
		// TODO Auto-generated constructor stub
	}

}
